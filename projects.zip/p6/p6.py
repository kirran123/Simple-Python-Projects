import pandas as pd
import matplotlib.pyplot as plt
file_path = 'weather.csv'  
weather_data = pd.read_csv(file_path)
weather_data['Formatted Date'] = pd.to_datetime(weather_data['Formatted Date'], utc=True)
weather_data.set_index('Formatted Date', inplace=True)
if not isinstance(weather_data.index, pd.DatetimeIndex):
    weather_data.index = pd.to_datetime(weather_data.index)
daily_temps = weather_data['Temperature (C)'].resample('D').mean()
plt.figure(figsize=(12, 6))
plt.plot(daily_temps, label='Daily Average Temperature (°C)', color='blue')
plt.title('Daily Temperature Trends Over Time')
plt.xlabel('Date')
plt.ylabel('Temperature (°C)')
plt.legend()
plt.grid()
plt.show()
seasonal_data = daily_temps.groupby(daily_temps.index.month).mean()
plt.figure(figsize=(12, 6))
plt.plot(seasonal_data, label='Average Monthly Temperature (°C)', marker='o', color='orange')
plt.title('Seasonal Temperature Variations')
plt.xlabel('Month')
plt.ylabel('Temperature (°C)')
plt.xticks(ticks=range(1, 13), labels=['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
plt.legend()
plt.grid()
plt.show()

