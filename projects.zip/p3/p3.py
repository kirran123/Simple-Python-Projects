import pandas as pd
import matplotlib.pyplot as plt
covid_data_path = 'covid19.csv'  
covid_df = pd.read_csv(covid_data_path)
countries_to_plot = ['Afghanistan', 'Albania', 'Algeria', 'Andorra']
subset_df = covid_df[covid_df['Country/Region'].isin(countries_to_plot)]
plt.figure(figsize=(10, 6))
for country in countries_to_plot:
    data = subset_df[subset_df['Country/Region'] == country]
    plt.plot(
        ['Last Week', 'Current'],  
        [data['Confirmed last week'].values[0], data['Confirmed'].values[0]],
        marker='o',
        label=country)
plt.title('COVID-19 Confirmed Cases Trends')
plt.xlabel('Time (Simulated)')
plt.ylabel('Confirmed Cases')
plt.legend()
plt.grid()
plt.show()
mock_population = {
    'Afghanistan': 38928346,
    'Albania': 2877797,
    'Algeria': 43851044,
    'Andorra': 77265}
subset_df.loc[:, 'Population'] = subset_df['Country/Region'].map(mock_population)
subset_df.loc[:, 'Cases per Capita'] = subset_df['Confirmed'] / subset_df['Population'] * 1e5
plt.figure(figsize=(8, 5))
plt.bar(subset_df['Country/Region'], subset_df['Cases per Capita'], color='skyblue')
plt.title('COVID-19 Cases per 100,000 People')
plt.xlabel('Country')
plt.ylabel('Cases per Capita')
plt.xticks(rotation=45)
plt.show()
plt.figure(figsize=(8, 5))
plt.bar(subset_df['Country/Region'], subset_df['Recovered / 100 Cases'], color='green')
plt.title('Recovery Rates per 100 Cases by Country')
plt.xlabel('Country')
plt.ylabel('Recovery Rate (%)')
plt.xticks(rotation=45)
plt.show()

