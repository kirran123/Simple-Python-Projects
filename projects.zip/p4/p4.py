import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error
import numpy as np
sales_data = pd.read_csv('sales.csv', encoding='latin1')
sales_data['Order_Date'] = pd.to_datetime(sales_data['Order_Date'], dayfirst=True, errors='coerce')
sales_data = sales_data.dropna(subset=['Order_Date'])
daily_sales = sales_data.groupby('Order_Date').agg({'Sales': 'sum'}).reset_index()
daily_sales['Days'] = (daily_sales['Order_Date'] - daily_sales['Order_Date'].min()).dt.days
X = daily_sales[['Days']]
y = daily_sales['Sales']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
mae = mean_absolute_error(y_test, y_pred)
print(f"RMSE: {rmse}")
print(f"MAE: {mae}")



