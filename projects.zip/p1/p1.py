import os
import pandas as pd
import numpy as np
file_path = 'Emp_Records.xlsx'  
df = pd.read_excel(file_path)
print("Initial Dataset Overview:")
print(df.info())
print("\nPreview of Data:")
print(df.head())
print("\nMissing Values Before Handling:")
print(df.isnull().sum())
numeric_cols = df.select_dtypes(include=['number']).columns
for col in numeric_cols:
    if df[col].notnull().any():  
        df[col] = df[col].fillna(df[col].median())
categorical_cols = df.select_dtypes(include=['object']).columns
for col in categorical_cols:
    if df[col].notnull().any():
        mode_value = df[col].mode()[0]
        df[col] = df[col].fillna(mode_value)
    else:
        df[col] = df[col].fillna('Unknown')
print("\nNumber of Duplicates Before Removal:", df.duplicated().sum())
df = df.drop_duplicates()
for col in numeric_cols:
    if df[col].notnull().any():
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        df[col] = np.where(df[col] < lower_bound, lower_bound, df[col])
        df[col] = np.where(df[col] > upper_bound, upper_bound, df[col])
date_cols = df.select_dtypes(include=['object']).columns
for col in date_cols:
    try:
        df[col] = pd.to_datetime(df[col], format='%Y-%m-%d', errors='coerce')
    except:
        pass
if 'Salary' in df.columns:
    df['Salary'] = df['Salary'].apply(
        lambda x: float(str(x).replace(',', '').strip()) if pd.notnull(x) else np.nan)
output_directory = os.getcwd()  
cleaned_file_path = os.path.join(output_directory, 'Cleaned_Emp_Records.xlsx')
df.to_excel(cleaned_file_path, index=False)
print(f"\nCleaned data saved to: {cleaned_file_path}")
print("\nFinal Dataset Overview:")
print(df.info())
print("\nPreview of Cleaned Data:")
print(df.head())
