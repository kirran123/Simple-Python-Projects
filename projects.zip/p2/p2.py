import pandas as pd
import re
file_path = 'reviews.csv' 
df = pd.read_csv(file_path)
def clean_text(text):
    if pd.isnull(text):
        return text
    text = re.sub(r'<[^>]*>', '', text)  
    text = re.sub(r'[^\w\s]', '', text)  
    return text
df['Review Text'] = df['Review Text'].apply(clean_text)
df['Review Text'] = df['Review Text'].fillna('No review provided')
categorical_columns = ['Division Name', 'Department Name', 'Class Name']
for col in categorical_columns:
    df[col] = df[col].fillna('Unknown')
encoded_columns = {}
for col in categorical_columns:
    df[col], encoded_columns[col] = pd.factorize(df[col])
output_path = 'cleaned_reviews.csv'
df.to_csv(output_path, index=False)
print("Cleaned Dataset Preview:")
print(df.head())
print("\nEncoded Mappings:")
for col, mapping in encoded_columns.items():
    print(f"{col}: {dict(enumerate(mapping))}")

