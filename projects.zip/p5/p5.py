import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import numpy as np
house_data = pd.read_csv('house_prices.csv')
print("Dataset Columns:")
print(house_data.columns)
house_data = house_data.dropna()
numeric_columns = house_data.select_dtypes(include=['float64', 'int64']).columns.tolist()
target_column = numeric_columns[-1]
numeric_columns.remove(target_column)
X = house_data[numeric_columns]
y = house_data[target_column]
print(f"Using features: {numeric_columns}")
print(f"Predicting target: {target_column}")
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)
lr_predictions = lr_model.predict(X_test)
rf_model = RandomForestRegressor(random_state=42, n_estimators=100)
rf_model.fit(X_train, y_train)
rf_predictions = rf_model.predict(X_test)
lr_mse = mean_squared_error(y_test, lr_predictions)
rf_mse = mean_squared_error(y_test, rf_predictions)
lr_rmse = np.sqrt(lr_mse)
rf_rmse = np.sqrt(rf_mse)
lr_mae = mean_absolute_error(y_test, lr_predictions)
rf_mae = mean_absolute_error(y_test, rf_predictions)
print("\nModel Performance:")
print(f"Linear Regression - RMSE: {lr_rmse:.2f}, MAE: {lr_mae:.2f}")
print(f"Random Forest - RMSE: {rf_rmse:.2f}, MAE: {rf_mae:.2f}")

