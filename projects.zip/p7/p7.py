import pandas as pd
from textblob import TextBlob
import matplotlib.pyplot as plt
import re
file_path = 'tweets.csv'  
tweets_data = pd.read_csv(file_path, encoding='utf-8')
print("Columns in the dataset:", tweets_data.columns)
print(tweets_data.head())
timestamp_column = None
for col in tweets_data.columns:
    if 'time' in col.lower() or 'date' in col.lower():
        timestamp_column = col
        print(f"Found timestamp column: {timestamp_column}")
        break
if timestamp_column is None:
    raise KeyError("No timestamp-like column found in the dataset. Please verify your file.")
tweets_data[timestamp_column] = pd.to_datetime(tweets_data[timestamp_column], errors='coerce')
tweets_data = tweets_data.dropna(subset=[timestamp_column])
def extract_hashtags(text):
    hashtags = re.findall(r'#\w+', str(text)) 
    return hashtags
tweets_data['hashtags'] = tweets_data['text'].apply(extract_hashtags)
def analyze_sentiment(text):
    return TextBlob(str(text)).sentiment.polarity
tweets_data['sentiment'] = tweets_data['text'].apply(analyze_sentiment)
def classify_sentiment(score):
    if score > 0:
        return 'Positive'
    elif score < 0:
        return 'Negative'
    else:
        return 'Neutral'
tweets_data['sentiment_category'] = tweets_data['sentiment'].apply(classify_sentiment)
tweets_data['date'] = tweets_data[timestamp_column].dt.date
sentiment_by_topic = pd.DataFrame(columns=['date', 'topic', 'sentiment'])
for _, row in tweets_data.iterrows():
    date = row['date']
    sentiment = row['sentiment_category']
    hashtags = row['hashtags']
    for hashtag in hashtags:
        sentiment_by_topic = sentiment_by_topic.append({
            'date': date,
            'topic': hashtag,
            'sentiment': sentiment
        }, ignore_index=True)
sentiment_by_topic_grouped = sentiment_by_topic.groupby(['date', 'topic', 'sentiment']).size().unstack(fill_value=0)
sentiment_by_topic_grouped = sentiment_by_topic_grouped.fillna(0)
topics = sentiment_by_topic_grouped.columns
plt.figure(figsize=(12, 6))
for topic in topics:
    topic_data = sentiment_by_topic_grouped[topic]
    topic_data.plot(kind='line', label=topic, ax=plt.gca())
plt.title('Sentiment Trends by Topic Over Time')
plt.xlabel('Date')
plt.ylabel('Number of Tweets')
plt.legend(title='Topic')
plt.grid()
plt.show()
plt.figure(figsize=(8, 6))
sentiment_by_topic['sentiment'].value_counts().plot(kind='bar', color=['green', 'gray', 'red'])
plt.title('Sentiment Distribution by Topic')
plt.xlabel('Sentiment')
plt.ylabel('Number of Tweets')
plt.xticks(rotation=0)
plt.grid()
plt.show()
