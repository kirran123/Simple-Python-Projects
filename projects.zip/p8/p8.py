import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, accuracy_score
file_path = 'news_articles.csv'  
data = pd.read_csv(file_path)
print("Column names in the dataset:")
print(data.columns)
text_column = input("Enter the column name for text data: ")
category_column = input("Enter the column name for category labels: ")
if text_column not in data.columns or category_column not in data.columns:
    raise ValueError(f"Columns '{text_column}' and '{category_column}' must exist in the dataset.")
texts = data[text_column]
categories = data[category_column]
texts = texts.str.lower()
X_train, X_test, y_train, y_test = train_test_split(texts, categories, test_size=0.2, random_state=42)
vectorizer = CountVectorizer(stop_words='english')  
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)
model = MultinomialNB()
model.fit(X_train_vec, y_train)
y_pred = model.predict(X_test_vec)
print("\nModel Evaluation:")
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

