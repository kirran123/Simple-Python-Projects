import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder
file_path = 'imdb_reviews.csv'
df = pd.read_csv(file_path)
print("Dataset Preview:")
print(df.head())
print("\nColumn Names:", df.columns)
review_column = input("Enter the column name for reviews: ").strip()
sentiment_column = input("Enter the column name for sentiment labels: ").strip()
X = df[review_column]
y = df[sentiment_column]
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y)  
class_counts = pd.Series(y).value_counts()
print("\nClass Distribution Before Balancing:")
print(class_counts)
min_samples = 2
balanced_df = df.groupby(sentiment_column).filter(lambda x: len(x) >= min_samples)
if len(balanced_df) < len(df):
    X = balanced_df[review_column]
    y = label_encoder.fit_transform(balanced_df[sentiment_column])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english', max_df=0.9, min_df=5)),
    ('classifier', LogisticRegression(max_iter=200))])
pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"\nAccuracy: {accuracy:.2f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))
new_reviews = [
    "The movie was fantastic! The performances were top-notch.",
    "I didn't like the movie at all. It was too slow and boring."]
predictions = pipeline.predict(new_reviews)
for review, sentiment in zip(new_reviews, predictions):
    print(f"\nReview: {review}\nPredicted Sentiment: {label_encoder.inverse_transform([sentiment])[0]}\n")

